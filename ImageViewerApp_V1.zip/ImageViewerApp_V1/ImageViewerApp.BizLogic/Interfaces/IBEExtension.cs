﻿using ImageViewerApp.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageViewerApp.BizLogic.Interfaces
{
    public interface IBEExtension
    {
        void ExecuteAlgorithm(AlgoEventArgs doWorkEventArgs);
    }
}
