﻿using ImageViewerApp.BizLogic.Interfaces;
using ImageViewerApp.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageViewerApp.BizLogic.BEExtensions
{
    internal class FilterBE : IBEExtension
    {
        public void ExecuteAlgorithm(AlgoEventArgs doWorkEventArgs)
        {
            ushort[] inputData = doWorkEventArgs.Input;
            int length = inputData.Length;
            ushort[] outputData = new ushort[length];
            for(int i = 0; i < length; i++)
            {
                 outputData[i] = (ushort)(inputData[i] * (0.1));
            }
            doWorkEventArgs.Result = outputData;
        }
    }
}
