﻿using ImageViewerApp.BizLogic.BEExtensions;
using ImageViewerApp.BizLogic.Interfaces;
using ImageViewerApp.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageViewerApp.BizLogic
{
    public class BizController
    {
        private readonly IDictionary<string, IBEExtension> myListOfBEComponents;
        public BizController() 
        {
            myListOfBEComponents= new Dictionary<string, IBEExtension>();     
        }

        public void Init()
        {
            myListOfBEComponents.Add("Filter", new FilterBE());
            myListOfBEComponents.Add("Normalize", new NormalizeBE());
        }

        public void CallAlgorithm(object cmd, AlgoEventArgs e) 
        {
            string algorithmName = cmd as string;

            switch(algorithmName) 
            {
                case "Filter":
                    myListOfBEComponents[algorithmName].ExecuteAlgorithm(e);
                    break;

                case "Normalize":
                    myListOfBEComponents[algorithmName].ExecuteAlgorithm(e);
                    break;

                default:
                    break;
            }
        }
    }
}
