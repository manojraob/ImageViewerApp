﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageViewerApp.Common
{
    public class AlgoEventArgs : EventArgs
    {
        private ushort[] myInputData = null;

        private ushort[] myResultData = null;

        private string myToolName = null;

        public AlgoEventArgs(ushort[] inputData, string toolName)
        {
            myInputData = inputData;
            myToolName = toolName;
        }
        public ushort[] Input
        {
            get
            { return myInputData; }
        }

        public string ToolName
        {
            get
            { return myToolName; }
        }

        public ushort[] Result
        {
            get
            { return myResultData; }
            set { myResultData = value; }
        }
    }
}
