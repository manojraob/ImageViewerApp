﻿using ImageViewerApp.BizLogic.Interfaces;
using ImageViewerApp.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageViewerApp.BizLogic.BEExtensions
{
    internal class NormalizeBE : IBEExtension
    {
        public void ExecuteAlgorithm(AlgoEventArgs doWorkEventArgs)
        {
            
        }
    }
}
