﻿using Microsoft.Win32;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ImageViewerApp.BizLogic;
using ImageViewerApp.Common;

namespace ImageViewerApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private BackgroundWorker worker = null;

        private BizController myBizController = null;

        private AlgoEventArgs myAlgoEventArgs = null;
        public MainWindow()
        {
            InitializeComponent();
            myBizController= new BizController();
            myBizController.Init();

            worker = new BackgroundWorker();
            worker.WorkerSupportsCancellation = true;
            worker.WorkerReportsProgress = true;
            worker.DoWork += worker_DoWork;
            worker.ProgressChanged += worker_ProgressChanged;
            worker.RunWorkerCompleted += worker_RunWorkerCompleted;
        }

        private void OnLoadImage(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                Uri fileUri = new Uri(openFileDialog.FileName);
                leftImageContainer.Source = new BitmapImage(fileUri);
            }
        }

        private void OnClearInputImage(object sender, RoutedEventArgs e)
        {
            if (leftImageContainer.Source != null) 
            {
                leftImageContainer.Source = null;
            }
        }

        private void OnFilterImage(object sender, RoutedEventArgs e)
        {
            if (leftImageContainer.Source == null) 
            {
                return;
            }
            BitmapSource bitmapSource = leftImageContainer.Source as BitmapSource;
            byte[] inputImageSource = BitmapSourceToArray(bitmapSource);
            myAlgoEventArgs = new AlgoEventArgs(inputImageSource, "Filter");
            worker.RunWorkerAsync(myAlgoEventArgs);
        }

        private void OnNormalizeImage(object sender, RoutedEventArgs e)
        {
            if (leftImageContainer.Source == null)
            {
                return;
            }
            BitmapSource bitmapSource = leftImageContainer.Source as BitmapSource;
            byte[] inputImageSource = BitmapSourceToArray(bitmapSource);
            myAlgoEventArgs = new AlgoEventArgs(inputImageSource, "Normalize");
            worker.RunWorkerAsync();
        }

        private byte[] BitmapSourceToArray(BitmapSource bitmapSource)
        {
            // Stride = (width) x (bytes per pixel)
            int stride = (int)bitmapSource.PixelWidth * (bitmapSource.Format.BitsPerPixel / 8);
            byte[] pixels = new byte[(int)bitmapSource.PixelHeight * stride];

            bitmapSource.CopyPixels(pixels, stride, 0);

            return pixels;
        }

        private BitmapSource BitmapSourceFromArray(byte[] pixels, int width, int height)
        {
            WriteableBitmap bitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);

            bitmap.WritePixels(new Int32Rect(0, 0, width, height), pixels, width * (bitmap.Format.BitsPerPixel / 8), 0);

            return bitmap;
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            for(; ; )
            {
                if (worker.CancellationPending == true)
                {
                    e.Cancel = true;
                    return;
                }
                var arg = e.Argument as AlgoEventArgs ;
                myBizController.CallAlgorithm(arg.ToolName, myAlgoEventArgs);
                if(myAlgoEventArgs.Result != null)
                {
                    e.Result = myAlgoEventArgs.Result;
                    return;
                }
            }
            //worker.ReportProgress(i);
            //System.Threading.Thread.Sleep(250);
            //}
            //e.Result = 42;

        }

        void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //lblStatus.Text = "Working... (" + e.ProgressPercentage + "%)";
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //if (e.Cancelled)
            //{
            //    lblStatus.Foreground = Brushes.Red;
            //    lblStatus.Text = "Cancelled by user...";
            //}
            //else
            //{
            //    lblStatus.Foreground = Brushes.Green;
            //    lblStatus.Text = "Done... Calc result: " + e.Result;
            //}
        }
    }
}